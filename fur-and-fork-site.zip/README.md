# Fur & Fork — Website (Vite + React + Tailwind)

This is the landing site for **Fur & Fork** — "Meals, memories, and wagging tails."

## Local Development
```bash
npm install
npm run dev
```
Visit http://localhost:5173

## Build
```bash
npm run build
npm run preview
```

## Netlify Deployment
1. Push this folder to a GitHub repo (e.g., `fur-and-fork-site`).
2. In Netlify: **Add new site → Import from Git → GitHub → pick your repo**.
3. Build command: **npm run build**
4. Publish directory: **dist**
5. Deploy.
