import React from 'react'
import { PawPrint, Coffee, Utensils, HeartHandshake, Dog, MapPin, Calendar, Instagram, Phone, Mail, Sparkles } from 'lucide-react'

const SectionTitle = ({ eyebrow, title, subtitle }) => (
  <div className="max-w-3xl mx-auto text-center">
    {eyebrow && <p className="uppercase tracking-widest text-xs md:text-sm text-amber-600 mb-2">{eyebrow}</p>}
    <h2 className="text-2xl md:text-4xl font-extrabold text-stone-800">{title}</h2>
    {subtitle && <p className="mt-3 text-stone-600 leading-relaxed">{subtitle}</p>}
  </div>
)

const Stat = ({ icon: Icon, label, value }) => (
  <div className="flex items-center gap-3">
    <div className="p-2 rounded-xl bg-emerald-50"><Icon className="w-5 h-5 text-emerald-700"/></div>
    <div>
      <div className="text-stone-900 font-semibold">{value}</div>
      <div className="text-stone-500 text-sm">{label}</div>
    </div>
  </div>
)

const MenuCard = ({ name, desc, price, icon: Icon }) => (
  <div className="rounded-2xl p-5 border bg-white/70 shadow-sm hover:shadow-md transition">
    <div className="flex items-start gap-4">
      <div className="p-2 rounded-xl bg-amber-50"> <Icon className="w-5 h-5 text-amber-700"/> </div>
      <div className="flex-1">
        <div className="flex items-center justify-between gap-4">
          <h4 className="font-semibold text-stone-800">{name}</h4>
          {price && <span className="text-stone-700 font-medium">{price}</span>}
        </div>
        <p className="text-stone-600 text-sm mt-1">{desc}</p>
      </div>
    </div>
  </div>
)

export default function App() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-stone-50 to-stone-100 text-stone-800">
      <header className="sticky top-0 z-30 backdrop-blur bg-white/70 border-b">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
          <a href="#home" className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-full bg-emerald-600 flex items-center justify-center text-white"><PawPrint className="w-5 h-5"/></div>
            <div className="leading-tight">
              <div className="font-extrabold text-lg tracking-tight">Fur & Fork</div>
              <div className="text-[10px] text-stone-600">Meals, memories, and wagging tails</div>
            </div>
          </a>
          <nav className="hidden md:flex items-center gap-6 text-sm">
            <a href="#menu" className="hover:text-emerald-700">Menu</a>
            <a href="#fur-babies" className="hover:text-emerald-700">Fur Babies</a>
            <a href="#story" className="hover:text-emerald-700">Our Story</a>
            <a href="#rescue" className="hover:text-emerald-700">Rescue</a>
            <a href="#visit" className="hover:text-emerald-700">Visit</a>
          </nav>
          <a href="#waitlist" className="px-3 py-2 rounded-xl bg-emerald-600 text-white text-sm font-semibold hover:bg-emerald-700">Join the Waitlist</a>
        </div>
      </header>

      <section id="home" className="relative overflow-hidden">
        <div className="max-w-6xl mx-auto px-4 py-16 md:py-24 grid md:grid-cols-2 gap-10 items-center">
          <div>
            <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight text-stone-900">Where dogs aren’t just allowed — they’re <span className="text-emerald-700">honored</span>.</h1>
            <p className="mt-4 text-lg text-stone-700">A whimsical, heart-forward dining experience in Rancho Cucamonga — crafted for fur babies and the humans they lovingly adopted.</p>
            <div className="mt-6 flex flex-wrap items-center gap-3">
              <a href="#menu" className="px-4 py-3 rounded-xl bg-stone-900 text-white font-semibold hover:bg-stone-800">Explore Menu</a>
              <a href="#visit" className="px-4 py-3 rounded-xl bg-white border font-semibold hover:bg-stone-50">Plan Your Visit</a>
            </div>
            <div className="mt-8 grid grid-cols-2 md:grid-cols-3 gap-6">
              <Stat icon={Dog} label="Dog beds & water bowls" value="Comfort-first"/>
              <Stat icon={HeartHandshake} label="Shelter partnerships" value="Rocky’s Rescue"/>
              <Stat icon={Coffee} label="Puppuccinos served" value="Daily joy"/>
            </div>
          </div>
          <div className="relative">
            <div className="aspect-square rounded-3xl bg-white shadow-xl border flex items-center justify-center">
              <div className="p-8 text-center">
                <PawPrint className="w-14 h-14 mx-auto text-emerald-600"/>
                <h3 className="mt-4 font-semibold text-xl">Fur & Fork</h3>
                <p className="text-stone-600 mt-1">Meals, memories, and wagging tails</p>
                <div className="mt-4 inline-flex items-center gap-2 text-stone-500 text-sm"><Utensils className="w-4 h-4"/> human & dog menus</div>
              </div>
            </div>
            <div className="absolute -bottom-4 -left-4 bg-emerald-600 text-white px-3 py-1 rounded-full text-xs shadow">Rancho Cucamonga • CA</div>
          </div>
        </div>
      </section>

      <section id="menu" className="py-16 md:py-24 border-t bg-white/70">
        <SectionTitle eyebrow="Our Kitchen" title="Human Menu Highlights" subtitle="Elevated comfort with a playful, brunch-forward heart."/>
        <div className="max-w-6xl mx-auto px-4 mt-10 grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          <MenuCard icon={Utensils} name="Bark-cuterie Board" desc="Artisan cheeses, seasonal fruit, nuts, local honey, toasted baguette." price="$18"/>
          <MenuCard icon={Utensils} name="Wagging Tail Waffle Stack" desc="Fluffy Belgian waffles, fresh berries, whipped cream, maple butter." price="$15"/>
          <MenuCard icon={Utensils} name="Rocky’s Rancheros" desc="Crispy tortilla, black beans, fried egg, queso fresco, avocado, roasted salsa." price="$16"/>
          <MenuCard icon={Utensils} name="The Loyal Companion Sandwich" desc="Roasted turkey, havarti, pesto mayo, arugula on grilled sourdough." price="$17"/>
          <MenuCard icon={Utensils} name="Short Rib Barley Risotto" desc="Slow-braised short rib, wild mushrooms, red wine jus, pecorino." price="$26"/>
          <MenuCard icon={Utensils} name="Butternut Squash Ravioli" desc="Sage brown butter, candied pecans, parmesan snow." price="$21"/>
        </div>
      </section>

      <section id="fur-babies" className="py-16 md:py-24">
        <SectionTitle eyebrow="For Our Fur Babies" title="Dog Menu Favorites" subtitle="Vet-approved, freshly cooked, no garlic/onion/salt — ever."/>
        <div className="max-w-6xl mx-auto px-4 mt-10 grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          <MenuCard icon={PawPrint} name="Rocky’s Chicken & Rice Bowl" desc="Steamed chicken, white rice, carrots, peas, warm bone broth." price="$9"/>
          <MenuCard icon={PawPrint} name="Sweet Potato & Salmon Feast" desc="Baked salmon flakes, mashed sweet potato, green beans (omega‑3)." price="$12"/>
          <MenuCard icon={PawPrint} name="Beef & Pumpkin Power Bowl" desc="Lean beef, pumpkin purée, peas, brown rice — digestion friendly." price="$10"/>
          <MenuCard icon={PawPrint} name="Birthday Pupcake" desc="Peanut butter & banana mini cake with yogurt frosting (custom name)." price="$6"/>
          <MenuCard icon={PawPrint} name="Frozen Yogurt Pup Cup" desc="Plain goat yogurt, mashed banana, topped with a blueberry." price="$4"/>
          <MenuCard icon={PawPrint} name="Bone Broth Bowl" desc="Slow-simmered chicken or beef broth for joints & immune support." price="$3"/>
        </div>
      </section>

      <section id="story" className="py-16 md:py-24 bg-white/70 border-t">
        <SectionTitle eyebrow="Our Mission" title="It all began with a dog named Rocky" subtitle={"To create a place where dogs are not just allowed — they are honored. A place where dogs bring their humans to share a beautiful meal, feel loved, and be celebrated, while helping the dogs who have yet to experience that kind of love."}/>
        <div className="max-w-5xl mx-auto px-4 mt-8 grid md:grid-cols-2 gap-8 items-center">
          <div className="rounded-3xl border bg-stone-50 p-6 shadow-sm">
            <p className="text-stone-700 leading-relaxed">Inspired by Rocky’s unconditional love, Fur & Fork celebrates the bond between fur babies and their humans. Every detail—from water bowls and dog beds to joyful menus—honors that bond.</p>
            <p className="text-stone-700 leading-relaxed mt-3">A portion of profits supports local shelters through <span className="font-semibold">Rocky’s Rescue Fund</span>, sponsoring meals and medical care for dogs waiting to be loved.</p>
            <div className="mt-4 flex items-center gap-2 text-emerald-700 font-semibold"><Sparkles className="w-4 h-4"/> Joy served daily.</div>
          </div>
          <div className="rounded-3xl border bg-emerald-50 p-6 shadow-sm">
            <h4 className="font-bold text-stone-800 mb-2">Core Values</h4>
            <ul className="space-y-2 text-stone-700">
              <li>• Dogs First, Always</li>
              <li>• Unconditional Love</li>
              <li>• Honor & Dignity for All Dogs</li>
              <li>• Shared Moments & Connection</li>
              <li>• Give Back to Those Still Waiting</li>
              <li>• Excellence in Care & Experience</li>
              <li>• Joy, Celebration & Community</li>
            </ul>
          </div>
        </div>
      </section>

      <section id="rescue" className="py-16 md:py-24">
        <SectionTitle eyebrow="Give Back" title="Rocky’s Rescue • Shelter Partnerships" subtitle="Dine for a Cause nights, adopt‑a‑pup patio pop‑ups, and a sponsorship wall where guests fund meals for shelter dogs."/>
        <div className="max-w-6xl mx-auto px-4 mt-10 grid md:grid-cols-3 gap-6">
          <div className="rounded-2xl p-6 border bg-white/80">
            <h4 className="font-semibold">Dine for a Cause (1st Sundays)</h4>
            <p className="text-sm text-stone-600 mt-1">Percentage of profits donated to a featured local shelter.</p>
          </div>
          <div className="rounded-2xl p-6 border bg-white/80">
            <h4 className="font-semibold">Adopt‑A‑Pup Patio</h4>
            <p className="text-sm text-stone-600 mt-1">Shelters bring adoptable dogs to meet our guests.</p>
          </div>
          <div className="rounded-2xl p-6 border bg-white/80">
            <h4 className="font-semibold">Sponsor a Meal</h4>
            <p className="text-sm text-stone-600 mt-1">Add $3 to fund a fresh bowl for a shelter dog.</p>
          </div>
        </div>
      </section>

      <section id="visit" className="py-16 md:py-24 bg-white/70 border-t">
        <SectionTitle eyebrow="Plan Your Visit" title="Rancho Cucamonga • Coming Soon" subtitle="Join our list to get opening news, soft‑launch invitations, and adoption event dates."/>
        <div className="max-w-4xl mx-auto px-4 mt-8 grid md:grid-cols-3 gap-6">
          <div className="rounded-2xl p-6 border bg-white/90">
            <div className="flex items-center gap-3"><MapPin className="w-5 h-5 text-emerald-700"/><span className="font-semibold">Location</span></div>
            <p className="text-sm text-stone-600 mt-2">Targeting Victoria Gardens area; final address TBA.</p>
          </div>
          <div className="rounded-2xl p-6 border bg-white/90">
            <div className="flex items-center gap-3"><Calendar className="w-5 h-5 text-emerald-700"/><span className="font-semibold">Timeline</span></div>
            <p className="text-sm text-stone-600 mt-2">Permitting & build‑out planning underway.</p>
          </div>
          <div id="waitlist" className="rounded-2xl p-6 border bg-white/90">
            <div className="flex items-center gap-3"><Mail className="w-5 h-5 text-emerald-700"/><span className="font-semibold">Join the Waitlist</span></div>
            <form className="mt-3 grid gap-3" onSubmit={(e)=>e.preventDefault()}>
              <input placeholder="Your name" className="px-3 py-2 rounded-xl border bg-white"/>
              <input placeholder="Email" type="email" className="px-3 py-2 rounded-xl border bg-white"/>
              <button className="px-4 py-2 rounded-xl bg-emerald-600 text-white font-semibold hover:bg-emerald-700">Notify Me</button>
              <p className="text-[11px] text-stone-500">By joining, you agree to receive occasional updates about Fur & Fork events and opening news.</p>
            </form>
          </div>
        </div>
      </section>

      <footer className="py-10 border-t bg-white/80">
        <div className="max-w-6xl mx-auto px-4 grid md:grid-cols-3 gap-8 items-center">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-full bg-emerald-600 flex items-center justify-center text-white"><PawPrint className="w-5 h-5"/></div>
            <div>
              <div className="font-bold">Fur & Fork</div>
              <div className="text-xs text-stone-500">Meals, memories, and wagging tails</div>
            </div>
          </div>
          <div className="text-sm text-stone-600">
            © {new Date().getFullYear()} Fur & Fork • Inspired by Rocky • Rancho Cucamonga, CA
          </div>
          <div className="flex items-center gap-4 justify-start md:justify-end text-stone-600">
            <a href="#" className="hover:text-stone-900"><Instagram className="w-5 h-5"/></a>
            <a href="tel:+19090000000" className="hover:text-stone-900"><Phone className="w-5 h-5"/></a>
            <a href="mailto:hello@furandfork.com" className="hover:text-stone-900"><Mail className="w-5 h-5"/></a>
          </div>
        </div>
      </footer>
    </div>
  )
}
